"""
AutoClip FastAPI Application Package
""" 