"""
Step 3: 内容评分 - 对每个话题进行质量评分，筛选出高质量内容
"""
import json
import logging
import re
from typing import List, Dict, Any, Optional
from pathlib import Path
from collections import defaultdict
from .scoring_backend import ScoringBackend, LLMScoringBackend

# 导入依赖
from ..utils.llm_client import LLMClient
from ..utils.text_processor import TextProcessor
from ..core.shared_config import PROMPT_FILES, METADATA_DIR, MIN_SCORE_THRESHOLD

logger = logging.getLogger(__name__)

# CLI `--min-score` 之类的显式覆盖：优先级最高。None = 用设置页保存的值，再退到 MIN_SCORE_THRESHOLD
MIN_SCORE_OVERRIDE: Optional[float] = None


def resolve_min_score_threshold() -> float:
    """显式覆盖 > 设置页「最低评分阈值」（settings.json，热重载）> 代码默认 0.7。
    设置页那个值以前只改了 API 进程的内存，流水线从来没读过。"""
    if MIN_SCORE_OVERRIDE is not None:
        return float(MIN_SCORE_OVERRIDE)
    try:
        from ..core.llm_manager import get_llm_manager
        value = get_llm_manager().get_processing_setting("min_score_threshold")
        if value is not None:
            value = float(value)
            if 0.0 < value <= 1.0:
                return value
            logger.warning(f"设置页的最低评分阈值 {value} 不在 (0, 1]，使用默认 {MIN_SCORE_THRESHOLD}")
    except Exception as e:  # noqa: BLE001
        logger.debug(f"读取设置页评分阈值失败，使用默认值: {e}")
    return float(MIN_SCORE_THRESHOLD)

class ClipScorer:
    """内容评分器"""
    
    def __init__(self, prompt_files: Dict = None, metadata_dir: Path = None,
                 scoring_backend: Optional[ScoringBackend] = None):
        self.text_processor = TextProcessor()
        self.metadata_dir = Path(metadata_dir) if metadata_dir else None
        
        # 加载提示词
        prompt_files_to_use = prompt_files if prompt_files is not None else PROMPT_FILES
        with open(prompt_files_to_use['recommendation'], 'r', encoding='utf-8') as f:
            self.recommendation_prompt = f.read()

        self.scoring_backend = scoring_backend if scoring_backend is not None else LLMScoringBackend(LLMClient(), self.recommendation_prompt)

        from .quality import load_srt_chunks
        self._srt_entries = load_srt_chunks(self.metadata_dir) if self.metadata_dir else []
    
    def score_clips(self, timeline_data: List[Dict]) -> List[Dict]:
        """
        为切片评分 (新版：按块批量处理，并使用LLM进行综合评估)
        """
        if not timeline_data:
            logger.warning("时间线数据为空，无法评分")
            return []
            
        logger.info(f"开始为 {len(timeline_data)} 个切片进行批量评分...")
        
        # 1. 按 chunk_index 对所有 timeline 数据进行分组
        timeline_by_chunk = defaultdict(list)
        for item in timeline_data:
            chunk_index = item.get('chunk_index')
            if chunk_index is not None:
                timeline_by_chunk[chunk_index].append(item)
            else:
                logger.warning(f"  > 话题 '{item.get('outline', '未知')}' 缺少 chunk_index，将被跳过。")
        
        all_scored_clips = []
        # 2. 每个块独立评分（并行，结果按块顺序）
        def score_chunk(item):
            chunk_index, chunk_items = item
            logger.info(f"处理块 {chunk_index}，其中包含 {len(chunk_items)} 个话题...")
            try:
                scored_chunk_items = self._get_llm_evaluation(chunk_items)
                if not scored_chunk_items:
                    logger.warning(f"块 {chunk_index} 的LLM评估返回为空，跳过。")
                return scored_chunk_items or []
            except Exception as e:
                logger.error(f"  > 处理块 {chunk_index} 进行评分时出错: {str(e)}")
                return []

        from .concurrency import map_chunks
        for scored_chunk_items in map_chunks(score_chunk, timeline_by_chunk.items()):
            all_scored_clips.extend(scored_chunk_items)

        # 4. 按最终得分对所有结果进行排序
        if all_scored_clips:
            all_scored_clips.sort(key=lambda x: x.get('final_score', 0), reverse=True)
            # 保持Step 2分配的固定ID，不再重新分配
            logger.info("按评分排序完成，保持原有固定ID不变")
            
            # 最终按ID排序，确保时间顺序的一致性
            all_scored_clips.sort(key=lambda x: int(x.get('id', 0)))
            logger.info("按ID排序完成，保持时间顺序")
                
        logger.info("所有切片评分完成")
        return all_scored_clips
    
    def _excerpt(self, clip: Dict) -> str:
        if not self._srt_entries:
            return ""
        from .quality import excerpt_between, to_seconds
        try:
            return excerpt_between(self._srt_entries, to_seconds(clip["start_time"]), to_seconds(clip["end_time"]))
        except (KeyError, ValueError, TypeError):
            return ""

    def _get_llm_evaluation(self, clips: List[Dict]) -> List[Dict]:
        """
        使用LLM进行批量评估，为每个clip添加 final_score 和 recommend_reason。
        数量对不上时按 outline 对齐，不再整块丢弃（#11）。
        """
        from .quality import align_scores

        try:
            input_for_llm = [
                {
                    "id": clip.get('id'),
                    "outline": clip.get('outline'),
                    "content": clip.get('content'),
                    "start_time": clip.get('start_time'),
                    "end_time": clip.get('end_time'),
                    "transcript": self._excerpt(clip),
                } for clip in clips
            ]

            parsed_list = self.scoring_backend.score(input_for_llm)
            source = "llm" if isinstance(self.scoring_backend, LLMScoringBackend) else "backend"
            scored, stats = align_scores(clips, parsed_list, score_source=source)
            logger.info(f"  > 评分对齐: 命中 {stats['matched']}，兜底 {stats['fallback']}")
            return scored

        except Exception as e:
            logger.error(f"LLM批量评估失败: {e}")
            scored, _ = align_scores(clips, [])
            return scored

    def save_scores(self, scored_clips: List[Dict], output_path: Path):
        """保存评分结果"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(scored_clips, f, ensure_ascii=False, indent=2)
        logger.info(f"评分结果已保存到: {output_path}")

def run_step3_scoring(timeline_path: Path, metadata_dir: Path = None, output_path: Optional[Path] = None, prompt_files: Dict = None,
                      scoring_backend: Optional[ScoringBackend] = None) -> List[Dict]:
    """
    运行Step 3: 内容评分与筛选
    
    Args:
        timeline_path: 时间线文件路径
        output_path: 输出文件路径
        prompt_files: 自定义提示词文件
        
    Returns:
        高分切片列表
    """
    # 加载时间线数据
    with open(timeline_path, 'r', encoding='utf-8') as f:
        timeline_data = json.load(f)
    
    if metadata_dir is None:
        metadata_dir = METADATA_DIR

    from .quality import load_profile, select_clips, save_report

    scorer = ClipScorer(prompt_files, metadata_dir=metadata_dir, scoring_backend=scoring_backend)
    scored_clips = scorer.score_clips(timeline_data)

    profile = load_profile(metadata_dir)
    threshold = resolve_min_score_threshold()
    high_score_clips, select_info = select_clips(scored_clips, threshold, profile)
    select_info["threshold"] = threshold
    save_report({"step3": select_info}, metadata_dir)
    logger.info(
        f"评分筛选: 候选 {select_info['candidates']} → 保留 {select_info['selected']}"
        f"（阈值 {threshold}，兜底补齐 {select_info['fallback_selected']}）"
    )

    all_scored_path = metadata_dir / "step3_all_scored.json"
    scorer.save_scores(scored_clips, all_scored_path)

    if output_path is None:
        output_path = metadata_dir / "step3_high_score_clips.json"
    scorer.save_scores(high_score_clips, output_path)

    return high_score_clips