"""RC156 Win QA #13: a Studio run killed with the app (LLM stage or render) ends failed with a reason after restart."""
import json
import os

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend.models.base import Base
from backend.models.project import Project, ProjectStatus
from backend.schemas.base import PaginationParams
from backend.services.project_service import ProjectService
from backend.services.studio import store
from backend.services.studio.restart_recovery import reconcile_interrupted_projects

OLD = 'previous-process'


@pytest.fixture
def sessions(tmp_path, monkeypatch):
    monkeypatch.setenv('AUTOCLIP_DATA_DIR', str(tmp_path))
    monkeypatch.setenv('AUTOCLIP_APP_DIR', str(tmp_path))
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)
    monkeypatch.setattr('backend.core.database.SessionLocal', factory)
    yield factory
    engine.dispose()


def _project(sessions, data, *, status=ProjectStatus.PROCESSING, project_id='p', auto=True, metadata=None):
    (store.directory(project_id) / 'metadata').mkdir(parents=True)
    (store.directory(project_id) / 'metadata' / 'studio.json').write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    with sessions() as db:
        db.add(Project(id=project_id, name=project_id, status=status, processing_config={'smart_import': {'auto_start': auto}},
                       project_metadata=metadata or {}))
        db.commit()


def _disk(project_id='p'):
    return json.loads((store.directory(project_id) / 'metadata' / 'studio.json').read_text(encoding='utf-8'))


def _row(sessions, project_id='p'):
    with sessions() as db:
        return ProjectService(db).get_project_with_stats(project_id)


def _production(instance=OLD, stage='production'):
    return {'generation': {'status': stage, 'auto_start': True, 'requested_platforms': ['douyin']},
            'analysis': {'status': 'running', 'phase': stage, 'run_id': 'run-1', 'message': '正在制作可发布成片', 'instance': instance},
            'drafts': [], 'jobs': [], 'output_variants': []}


@pytest.mark.parametrize('stage', ['production', 'screening'])
def test_startup_closes_a_run_killed_during_the_llm_stage(sessions, stage):
    _project(sessions, _production(stage=stage))
    assert reconcile_interrupted_projects(sessions) == ['p']
    disk = _disk()
    assert disk['generation']['status'] == 'failed'
    assert disk['generation']['error'] == store.RESTART_MESSAGE == '服务已重启，请重新生成'
    assert disk['generation']['error_code'] == 'service_restarted'
    assert disk['generation']['failure_stage'] == stage
    assert disk['analysis']['status'] == 'failed' and disk['analysis']['error'] == store.RESTART_MESSAGE
    assert 'message' not in disk['analysis'] and 'instance' not in disk['analysis']  # no stale 「正在制作可发布成片」
    assert disk['analysis']['run_id'] == 'run-1'
    row = _row(sessions)
    assert row.status.value == 'failed'
    assert row.error_message == store.RESTART_MESSAGE and row.error_code == 'service_restarted'
    # Idempotent: a second restart changes nothing.
    assert reconcile_interrupted_projects(sessions) == []


def test_previous_release_shape_completed_with_zero_clips_is_failed(sessions):
    # Before #8 the clips-only child run wrote completed while generation stayed in production.
    _project(sessions, _production(), status=ProjectStatus.COMPLETED)
    reconcile_interrupted_projects(sessions)
    assert _row(sessions).status.value == 'failed'


def test_home_list_heals_an_interrupted_run_without_the_startup_pass(sessions):
    _project(sessions, _production())
    with sessions() as db:
        listing = ProjectService(db).get_projects_paginated(PaginationParams())
    item = listing.items[0]
    assert item.status.value == 'failed' and item.error_message == store.RESTART_MESSAGE
    assert _disk()['generation']['status'] == 'failed'


def test_run_owned_by_this_process_is_left_running(sessions):
    _project(sessions, _production(instance=store.INSTANCE))
    assert reconcile_interrupted_projects(sessions) == []
    assert _disk()['generation']['status'] == 'production'
    with sessions() as db:
        ProjectService(db).get_projects_paginated(PaginationParams())
    assert _row(sessions).status.value == 'processing'


def test_live_cli_producer_is_not_failed_by_the_desktop(sessions):
    import psutil
    data = _production()
    data['generation']['producer'] = {'pid': os.getppid(), 'created_at': psutil.Process(os.getppid()).create_time()}
    _project(sessions, data)
    assert reconcile_interrupted_projects(sessions) == []
    assert store.read('p')['analysis']['status'] == 'running'
    assert _disk()['generation']['status'] == 'production'


def test_dead_cli_producer_is_recovered(sessions):
    data = _production()
    data['generation']['producer'] = {'pid': 2 ** 22 + 12345, 'created_at': 1.0}
    _project(sessions, data)
    assert reconcile_interrupted_projects(sessions) == ['p']
    assert _row(sessions).status.value == 'failed'


def test_killed_during_render_has_a_reason_on_the_project(sessions):
    # RC156 case 4b: previously failed with an empty error_message.
    _project(sessions, {
        'generation': {'status': 'rendering', 'auto_start': True},
        'analysis': {'status': 'running', 'phase': 'rendering', 'run_id': 'r', 'instance': OLD},
        'drafts': [{'id': 'd1'}, {'id': 'd2'}],
        'jobs': [{'job_id': 'j1', 'status': 'running', 'instance': OLD}],
        'output_variants': [{'id': 'v1', 'render_job_id': 'j1', 'status': 'running'},
                            {'id': 'v2', 'status': 'queued'}]})
    assert reconcile_interrupted_projects(sessions) == ['p']
    disk = _disk()
    assert [v['status'] for v in disk['output_variants']] == ['failed', 'failed']
    assert {v['error_code'] for v in disk['output_variants']} == {'service_restarted'}
    assert disk['jobs'][0]['error_code'] == 'service_restarted'
    assert disk['generation']['status'] == 'failed' and disk['generation']['error'] == store.RESTART_MESSAGE
    assert disk['generation']['error_code'] == 'service_restarted'
    assert disk['analysis']['error'] == store.RESTART_MESSAGE
    row = _row(sessions)
    assert row.status.value == 'failed' and row.error_message == store.RESTART_MESSAGE and row.error_code == 'service_restarted'


def test_render_killed_after_one_saved_video_is_partial_and_keeps_it(sessions):
    _project(sessions, {
        'generation': {'status': 'rendering', 'auto_start': True},
        'analysis': {'status': 'running', 'phase': 'rendering', 'run_id': 'r', 'instance': OLD},
        'drafts': [{'id': 'd1'}, {'id': 'd2'}],
        'jobs': [{'job_id': 'j1', 'status': 'completed', 'instance': OLD}, {'job_id': 'j2', 'status': 'running', 'instance': OLD}],
        'output_variants': [{'id': 'v1', 'render_job_id': 'j1', 'status': 'completed'},
                            {'id': 'v2', 'render_job_id': 'j2', 'status': 'running'}]})
    reconcile_interrupted_projects(sessions)
    disk = _disk()
    assert disk['generation']['status'] == 'partial' and disk['generation']['completed_variant_count'] == 1
    assert disk['output_variants'][0]['status'] == 'completed'


def _render_run(jobs, variants):
    return {'generation': {'status': 'rendering', 'auto_start': True},
            'analysis': {'status': 'running', 'phase': 'rendering', 'run_id': 'r', 'instance': OLD},
            'drafts': [{'id': f'd{i}'} for i in range(1, len(variants) + 1)], 'jobs': jobs, 'output_variants': variants}


def _linked(index, status, **job):
    identity = [f'v{index}', f'd{index}', 1, None, f'a{index}']
    return ({'job_id': f'j{index}', 'status': status, 'instance': OLD, 'variant_links': [identity], **job},
            {'id': f'v{index}', 'draft_id': f'd{index}', 'draft_revision': 1, 'render_attempt_id': f'a{index}',
             'render_job_id': f'j{index}', 'status': 'running'})


def test_render_killed_after_one_saved_video_tells_the_project_why(sessions):
    # RC156 #30: one video saved, the next one killed mid-render. The project failed with no reason and no code.
    done_job, done = _linked(1, 'completed', cover_pending=True)
    cut_job, cut = _linked(2, 'running')
    _project(sessions, _render_run([done_job, cut_job], [done, cut]))
    assert reconcile_interrupted_projects(sessions) == ['p']
    disk = _disk()
    assert disk['generation']['status'] == 'partial' and disk['generation']['completed_variant_count'] == 1
    assert disk['generation']['error'] == store.RESTART_MESSAGE and disk['generation']['error_code'] == 'service_restarted'
    first, second = disk['output_variants']
    assert first['status'] == 'completed'
    assert second['status'] == 'failed' and second['error_code'] == 'service_restarted'  # the card's retry finishes it
    row = _row(sessions)
    assert row.status.value == 'failed'
    assert row.error_message == store.RESTART_MESSAGE and row.error_code == 'service_restarted'


def test_render_killed_after_every_video_was_saved_stays_completed(sessions):
    # Killed while the last cover was pending: every video exists, so nothing is lost and nothing is retried.
    jobs, variants = zip(*(_linked(1, 'completed'), _linked(2, 'completed', cover_pending=True)))
    _project(sessions, _render_run(list(jobs), list(variants)))
    reconcile_interrupted_projects(sessions)
    disk = _disk()
    assert disk['generation']['status'] == 'completed' and disk['generation']['completed_variant_count'] == 2
    assert 'error' not in disk['generation'] and 'error_code' not in disk['generation']
    row = _row(sessions)
    assert row.status.value == 'completed' and row.error_message is None and row.error_code is None


def test_retrying_the_restarted_video_clears_the_reason():
    data = {'generation': {'status': 'rendering', 'error': store.RESTART_MESSAGE, 'error_code': 'service_restarted'},
            'analysis': {'run_id': 'r'}, 'jobs': [],
            'output_variants': [{'id': 'v1', 'status': 'completed'}, {'id': 'v2', 'status': 'completed'}]}
    store.settle_generation(data)
    assert data['generation']['status'] == 'completed'
    assert 'error' not in data['generation'] and 'error_code' not in data['generation']


def test_project_reason_prefers_the_generation_over_a_stale_task_error(sessions):
    from backend.models.task import Task, TaskStatus, TaskType
    _project(sessions, _production())
    with sessions() as db:
        db.add(Task(project_id='p', name='old', task_type=TaskType.VIDEO_PROCESSING, status=TaskStatus.FAILED, error_message='上一次的旧错误'))
        db.commit()
    reconcile_interrupted_projects(sessions)
    assert _row(sessions).error_message == store.RESTART_MESSAGE


def test_manual_confirmation_run_is_failed_and_keeps_its_wording(sessions):
    data = _production()
    data['generation'] = {'status': 'awaiting_confirmation', 'auto_start': False}
    data['analysis']['message'] = '开始制作所选内容'
    _project(sessions, data, auto=False)
    assert reconcile_interrupted_projects(sessions) == ['p']
    disk = _disk()
    assert disk['analysis']['status'] == 'failed' and disk['analysis']['error'] == '服务已重启，请重试分析'
    assert disk['analysis']['error_code'] == 'service_restarted' and 'message' not in disk['analysis']
    row = _row(sessions)
    assert row.status.value == 'failed' and row.error_message == '服务已重启，请重试分析'


def test_one_unreadable_project_does_not_stop_the_others(sessions):
    _project(sessions, _production(), project_id='good')
    (store.directory('bad') / 'metadata').mkdir(parents=True)
    (store.directory('bad') / 'metadata' / 'studio.json').write_text('{not json', encoding='utf-8')
    with sessions() as db:
        db.add(Project(id='bad', name='bad', status=ProjectStatus.PROCESSING, processing_config={'smart_import': {'auto_start': True}}))
        db.commit()
    assert reconcile_interrupted_projects(sessions) == ['good']


def test_restart_code_is_known_and_never_reported():
    from backend.core import sentry_setup
    assert 'service_restarted' in sentry_setup.STUDIO_ERROR_CODES
    assert 'service_restarted' in sentry_setup.UNREPORTED_STUDIO_ERROR_CODES


def test_long_video_stuck_in_processing_across_restarts_is_failed(sessions):
    """RC156 #13 case 3 (c3-long): analysis may already look failed while generation stays in
    production and the project index stays processing forever. Startup must close it."""
    # Disk shape after the previous process died mid clip_finder and an in-memory-only
    # recovery flipped analysis without writing/settling generation.
    _project(sessions, {
        'generation': {'status': 'production', 'auto_start': True},
        'analysis': {'status': 'failed', 'phase': 'production', 'run_id': 'r',
                     'message': '正在制作可发布成片'},  # stale message, no error
        'drafts': [], 'jobs': [], 'output_variants': []},
        status=ProjectStatus.PROCESSING)
    assert reconcile_interrupted_projects(sessions) == ['p']
    row = _row(sessions)
    assert row.status.value == 'failed'
    assert row.error_message == store.RESTART_MESSAGE and row.error_code == 'service_restarted'
    disk = _disk()
    assert disk['generation']['status'] == 'failed'
    assert disk['analysis']['error'] == store.RESTART_MESSAGE and 'message' not in disk['analysis']
    # Home card reads studio_generation_status=failed → 「重新生成」 entry.
    assert (row.settings or {}).get('studio_generation_status') == 'failed'
